BANCO_DE_DADOS="postgresql://postgres.ajulkvuhcdyemztdaqlg:ArboBoW2kRfqHcE0@aws-0-sa-east-1.pooler.supabase.com:5432/postgres   "
SEGREDO_JWT="PA9+/1R/r36gKLVdVBdILSIzChS/TQ7Gwiajej8ODy9QgJNvVNYQGAftsVXfeQlbabVo8Ecv6O9wzGy3BX3ICw=="
